const { test, expect } = require('@playwright/test');
const HomePage = require('../pages/HomePage');
const { baseUrl } = require('../config/env');
const { extractNumber } = require('../utils/helpers');

const selectedState = 'Bihar';

async function openBihar(page) {
  const home = new HomePage(page);
  await home.open(baseUrl);
  await home.selectState(selectedState);
  await home.resultHeading.waitFor();
  return home;
}

test('TC_001 Verify COVID-19 Tracker heading', async ({ page }) => {
  await page.goto(baseUrl);

  await expect(page.getByRole('heading', { name: 'COVID-19 Tracker - India' })).toBeVisible();
});

test('TC_002 Verify State dropdown options are displayed', async ({ page }) => {
  const home = new HomePage(page);
  await home.open(baseUrl);

  await expect(home.stateDropdown).toBeVisible();
  const states = await home.getStateNames();

  console.log('Total States:', states.length);
  expect(states.length).toBeGreaterThan(1);
});

test('TC_003 Verify pie chart is visible after selecting Bihar', async ({ page }) => {
  const home = await openBihar(page);

  await expect(home.pieChart).toBeVisible();
});

test('TC_004 Verify Total Cases matches component sum', async ({ page }) => {
  const home = await openBihar(page);

  const totalCases = extractNumber(await home.totalCases.textContent());
  const activeCases = extractNumber(await home.activeCases.textContent());
  const recovered = extractNumber(await home.recovered.textContent());
  const deaths = extractNumber(await home.deaths.textContent());

  expect(totalCases).toBe(activeCases + recovered + deaths);
});

test('TC_005 Verify result cards are displayed properly', async ({ page }) => {
  const home = await openBihar(page);

  await expect(home.totalCases).toBeVisible();
  await expect(home.activeCases).toBeVisible();
  await expect(home.recovered).toBeVisible();
  await expect(home.deaths).toBeVisible();
});