const { test, expect } = require('@playwright/test');
const HomePage = require('../pages/HomePage');
const { baseUrl } = require('../config/env');
const { waitForPage } = require('../utils/helpers');
const { state, additionalStates } = require('../test-data/states.json');

test.describe('COVID tracker UI validation', () => {
  test('Verify page title', async ({ page }) => {
    await page.goto(baseUrl);
    await waitForPage(page);
    await expect(page).toHaveTitle(/InerG/i);
  });

  test('Verify state dropdown is visible', async ({ page }) => {
    const home = new HomePage(page);
    await page.goto(baseUrl);
    await waitForPage(page);
    await expect(home.stateDropdown).toBeVisible();
  });

  test('Verify Kerala statistics are displayed', async ({ page }) => {
    const home = new HomePage(page);
    await page.goto(baseUrl);
    await home.selectState(state);

    await expect(home.totalCases).toBeVisible();
    await expect(home.activeCases).toBeVisible();
    await expect(home.recovered).toBeVisible();
    await expect(home.deaths).toBeVisible();
  });

  test('Verify pie chart is visible', async ({ page }) => {
    const home = new HomePage(page);
    await page.goto(baseUrl);
    await home.selectState(state);
    await expect(home.pieChart).toBeVisible();
  });

  test('Verify line chart is visible', async ({ page }) => {
    const home = new HomePage(page);
    await page.goto(baseUrl);
    await home.selectState(state);
    await expect(home.lineChart).toBeVisible();
  });

  test('Verify map is visible', async ({ page }) => {
    const home = new HomePage(page);
    await page.goto(baseUrl);
    await home.selectState(state);
    await expect(home.mapMarker).toBeVisible();
  });

  test('Verify multiple states can be selected', async ({ page }) => {
    const home = new HomePage(page);
    await page.goto(baseUrl);

    for (const selectedState of [state, ...additionalStates]) {
      await home.selectState(selectedState);
      await expect(home.resultHeading).toHaveText(`Results for ${selectedState}`);
    }
  });
});