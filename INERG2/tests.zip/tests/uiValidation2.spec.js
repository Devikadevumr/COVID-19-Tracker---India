const { test, expect } = require('@playwright/test');
const HomePage = require('../pages/HomePage');
const { baseUrl } = require('../config/env');

async function selectKerala(page) {
  const home = new HomePage(page);
  await page.goto(baseUrl);
  await home.selectState('Kerala');
  await expect(home.resultHeading).toHaveText('Results for Kerala');
  return home;
}

test('TCIN_02 Verify State Dropdown Options', async ({ page }) => {
  const home = new HomePage(page);
  await page.goto(baseUrl);

  await expect(home.stateDropdown).toBeVisible();
  const options = await home.getStateNames();

  console.log('State Count:', options.length);
  expect(options.length).toBeGreaterThan(1);
  expect(options).toContain('Kerala');
});

test('TCIN_09 Verify Results Heading for Kerala', async ({ page }) => {
  const home = await selectKerala(page);

  await expect(home.resultHeading).toBeVisible();
});

test('TCIN_23 Verify Text Colour Consistency', async ({ page }) => {
  await selectKerala(page);

  const headings = page.locator('h1, h2, h3');
  await expect(headings.first()).toBeVisible();

  const headingColors = await headings.evaluateAll((elements) =>
    elements.map((element) => getComputedStyle(element).color)
  );
  expect(new Set(headingColors).size).toBe(1);
});

test('TCIN_24 Verify Tooltip on Chart Data Points', async ({ page }) => {
  await selectKerala(page);

  const chartPoint = page.locator('.scatterlayer .point').first();
  await expect(chartPoint).toBeVisible();
  await chartPoint.hover({ force: true });

  await expect(page.locator('.hovertext').first()).toBeVisible();
});

test('TCIN_25 Verify Map Labels Are Visible', async ({ page }) => {
  const home = await selectKerala(page);

  await expect(page.locator('.leaflet-container')).toBeVisible();
  await expect(home.mapMarker).toBeVisible();
});
