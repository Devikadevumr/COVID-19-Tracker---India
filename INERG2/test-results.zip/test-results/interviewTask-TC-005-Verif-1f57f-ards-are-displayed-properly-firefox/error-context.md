# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: interviewTask.spec.js >> TC_005 Verify result cards are displayed properly
- Location: tests\interviewTask.spec.js:50:1

# Error details

```
Tearing down "context" exceeded the test timeout of 30000ms.
```